intall before running



npm install
npm install remixicon --save
npm run dev


made by HaHa