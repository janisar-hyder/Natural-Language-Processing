import React, { useState, useEffect } from 'react';
import './App.css';
import 'remixicon/fonts/remixicon.css';

const images = [
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-1.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-2.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-3.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-4.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-5.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-6.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-7.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-8.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-9.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-10.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-11.webp',
  'https://raw.githubusercontent.com/mobalti/open-props-interfaces/main/image-gallery/images/img-12.webp',
];

const App = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [imageSize, setImageSize] = useState('');

  const openDialog = (index) => {
    setSelectedIndex(index);
    setIsDialogOpen(true);
    getImageSize(images[index]);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
  };

  const handlePrev = () => {
    const newIndex = selectedIndex > 0 ? selectedIndex - 1 : images.length - 1;
    setSelectedIndex(newIndex);
    getImageSize(images[newIndex]);
  };

  const handleNext = () => {
    const newIndex = selectedIndex < images.length - 1 ? selectedIndex + 1 : 0;
    setSelectedIndex(newIndex);
    getImageSize(images[newIndex]);
  };

  const getImageSize = (url) => {
    const img = new Image();
    img.onload = () => {
      setImageSize(`${img.width} x ${img.height}`);
    };
    img.src = url;
  };

  return (
    <div>
      <header><h1>Showcase</h1></header>
      <main>
        <section>
          <ImageGallery images={images} onImageClick={openDialog} />
          {isDialogOpen && (
            <Dialog
              image={images[selectedIndex]}
              onClose={closeDialog}
              onPrev={handlePrev}
              onNext={handleNext}
              size={imageSize}
            />
          )}
        </section>
      </main>
    </div>
  );
};

const ImageGallery = ({ images, onImageClick }) => (
  <div className="imageGallery">
    {images.map((src, index) => (
      <button key={index} onClick={() => onImageClick(index)}>
        <picture>
          <img width="309" height="309" src={src} alt={`A cute cat ${index + 1}`} loading="lazy" />
        </picture>
      </button>
    ))}
  </div>
);

const Dialog = ({ image, onClose, onPrev, onNext, size }) => (
  <div className="dialog" id="dialog">
    <div className="dialogContainer">
      <picture>
        <img className="previewImage" src={image} alt="Preview" loading="lazy" />
      </picture>
      <p>Image size: {size}</p>
      <div className="controls">
        <button id="prevBtn" onClick={onPrev}>
          <i className="ri-arrow-left-circle-fill"></i>
        </button>
        <button id="nextBtn" onClick={onNext}>
          <i className="ri-arrow-right-circle-fill"></i>
        </button>
        <button id="downloadBtn" onClick={() => downloadImage(image)}>
          <i className="ri-download-line"></i> Download
        </button>
      </div>
    </div>
    <button id="closeDialogBtn" className="closeDialog" onClick={onClose}>
      <i className="ri-close-line"></i>
    </button>
  </div>
);

const downloadImage = (src) => {
  fetch(src)
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = src.split('/').pop();
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    })
    .catch(err => console.error('Error downloading the image', err));
};

export default App;
